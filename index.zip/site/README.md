# Career Lens – deploy guide
Files: index.html, manifest.webmanifest, sw.js, icons/. It is a static site: no server, no database, no API keys.

## Option A: Netlify (fastest, 2 minutes)
1. Go to app.netlify.com/drop
2. Drag the whole career-lens-site folder onto the page.
3. You get a public https link. Rename it under Site settings > Change site name.

## Option B: GitHub Pages (free, good for the team)
1. Create a GitHub repo, upload all files to the main branch.
2. Settings > Pages > Deploy from branch > main > Save.
3. Live at https://<username>.github.io/<repo>/

## Make it an app
- Android Chrome: open the site > menu > Install app.
- Desktop Chrome/Edge: click the install icon in the address bar.
- iPhone Safari: Share > Add to Home Screen.
- Google Play: paste your live URL into pwabuilder.com, choose Android, download the package (needs a $25 Google Play developer account).

## Test before sharing
Open the live link, upload a PDF, run both samples, then switch to airplane mode and reload: the shell should still open.
